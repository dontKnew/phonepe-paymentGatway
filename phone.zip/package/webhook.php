<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/vendor/autoload.php';

use PhonePe\Env;
use PhonePe\payments\v1\models\request\builders\InstrumentBuilder;
use PhonePe\payments\v1\models\request\builders\PgPayRequestBuilder;
use PhonePe\payments\v1\PhonePePaymentClient;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postData = file_get_contents('php://input');
    $logsDir = __DIR__ . '/logs';
    if (!is_dir($logsDir)) {
        mkdir($logsDir, 0755, true);
    }
    $logFile = $logsDir . '/log_' . date('Y-m-d') . '.log';

    $logEntry = '[' . date('Y-m-d H:i:s') . '] Received Data: ' . $postData . PHP_EOL;
    file_put_contents($logFile, $logEntry, FILE_APPEND);

    if (isset($_SERVER['HTTP_X_VERIFY'])) {
        $xVerify = $_SERVER['HTTP_X_VERIFY'];

        $phonePePaymentsClient = new PhonePePaymentClient(API_MERCHAT_ID, API_KEY, API_KEY_INDEX, Env::UAT, true);
    
        $isValid = $phonePePaymentsClient->verifyCallback($postData, $xVerify);
        $logEntry = '[' . date('Y-m-d H:i:s') . '] Verification: ' . ($isValid ? 'Success' : 'Failed') . PHP_EOL;
        file_put_contents($logFile, $logEntry, FILE_APPEND);
        if ($isValid) {
            echo json_encode(['status' => 'success', 'message' => 'Data verified and logged successfully.']);
        } else {
            http_response_code(400); // Bad Request
            echo json_encode(['status' => 'error', 'message' => 'Invalid signature.']);
        }
    } else {
        $logEntry = '[' . date('Y-m-d H:i:s') . '] Missing x-verify header.' . PHP_EOL;
        file_put_contents($logFile, $logEntry, FILE_APPEND);
        http_response_code(400); // Bad Request
        echo json_encode(['status' => 'error', 'message' => 'Missing x-verify header.']);
    }
} else {
    $logEntry = '[' . date('Y-m-d H:i:s') . '] Invalid request method: ' . $_SERVER['REQUEST_METHOD'] . PHP_EOL;
    file_put_contents($logFile, $logEntry, FILE_APPEND);
    http_response_code(405); // Method Not Allowed
    echo json_encode(['status' => 'error', 'message' => 'Only POST requests are allowed.']);
}
